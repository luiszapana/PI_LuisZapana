package com.portfolio.laz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LazApplication {

	public static void main(String[] args) {
		SpringApplication.run(LazApplication.class, args);
	}

}
