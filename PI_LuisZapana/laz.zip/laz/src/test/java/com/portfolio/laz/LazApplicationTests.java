package com.portfolio.laz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LazApplicationTests {

	@Test
	void contextLoads() {
	}

}
